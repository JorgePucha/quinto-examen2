
from . import views
from django.urls import path,include
urlpatterns = [
    path('', views.loginPage,name="autenticar"),
    path('logout', views.logoutPage,name="salir"),
]
