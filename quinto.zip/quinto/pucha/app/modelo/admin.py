from django.contrib import admin
from .models import Producto
class AdminProducto(admin.ModelAdmin):
    list_display=['codigo','descripcion','marca','tipo','stock','precio']
    list_editable=['descripcion','marca','tipo','stock','precio']
    list_filter=['codigo','descripcion','marca']
    search_fields=['codigo','descripcion','marca']
    class Meta:
        model=Producto
admin.site.register(Producto,AdminProducto)
