from django.db import models
class Producto(models.Model):
    listaTipo=(
        ('c',"Comida"),
        ('b',"Bebida"),
        ('b',"Otros"),
    )
    codigo=models.CharField('Codigo',max_length=10,unique=True)
    descripcion=models.CharField('Descripcion',max_length=25,blank=False,null=False)
    marca=models.CharField('Marca',max_length=25,blank=False,null=False)
    tipo=models.CharField(max_length=10,default="c",choices=listaTipo)
    stock=models.IntegerField(unique=True)
    precio=models.DecimalField(max_digits=5,decimal_places=2)
    def __str__(self):
        return self.codigo
