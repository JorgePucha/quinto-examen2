from django.apps import AppConfig


class ModeloConfig(AppConfig):
    name = 'modelo'
