from django.shortcuts import render
from django.http import HttpResponse
from app.modelo.models import Producto
from .forms import FormularioProducto
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required

def principal(request):
    lista=Producto.objects.all()
    context={
        'lista':lista,
    }
    return render(request,'productos/principal_producto.html',context)
def crear(request):
    #return HttpResponse('Es la interfaz de crear un Cliente')
    formulario=FormularioProducto(request.POST)
    if request.method == "POST":
        if formulario.is_valid():
            datos=formulario.cleaned_data
            producto=Producto()
            producto.codigo=datos.get('codigo')
            producto.precio=datos.get('precio')
            producto.descripcion=datos.get('descripcion')
            producto.stock=datos.get('stock')
            producto.tipo=datos.get('tipo')
            producto.marca=datos.get('marca')
            producto.save()
            return redirect(principal)
    context={
        'f':formulario
    }
    return render(request,'productos/crear_producto.html',context)
def modificar(request):
    codigo=request.GET['codigo']
    producto=Producto.objects.get(codigo=codigo)
    if request.method=="POST":
        formulario=FormularioProducto(request.POST,instance=producto)
        if formulario.is_valid():
            datos=formulario.cleaned_data
            producto.descripcion=datos.get('descripcion')
            producto.stock=datos.get('stock')
            producto.marca=datos.get('marca')
            producto.save()
            return redirect(principal)
    else:
        formulario=FormularioProducto(instance=producto)
    context={
        'f':formulario,
    }
    return render(request,'productos/modificar_producto.html',context)
def eliminar(request):
    dni = request.GET['codigo']
    producto = Producto.objects.get(codigo= dni)
    if request.method == 'POST':
        producto.delete()
        return redirect(principal)
    context = {
        'p' : producto
    }
    return render(request, 'productos/eliminar_producto.html', context)

def cancelar(request):
    return redirect(principal)
