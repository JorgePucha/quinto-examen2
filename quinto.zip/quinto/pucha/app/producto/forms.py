from django import forms
from app.modelo.models import Producto
class FormularioProducto(forms.ModelForm):
    class Meta:
        model=Producto
        fields=['codigo','descripcion','marca','tipo','stock','precio']
